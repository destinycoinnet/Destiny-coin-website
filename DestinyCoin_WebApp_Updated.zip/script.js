const tg = window.Telegram.WebApp;
tg.expand();

let coins = 0;
const button = document.getElementById("mineButton");
const coinDisplay = document.getElementById("coinCount");

button.addEventListener("click", () => {
  coins += Math.floor(Math.random() * 5) + 1;
  coinDisplay.textContent = coins;

  tg.MainButton.text = `Withdraw ${coins} DC`;
  tg.MainButton.show();

  tg.MainButton.onClick(() => {
    tg.sendData(`withdraw:${coins}`);
  });
});
